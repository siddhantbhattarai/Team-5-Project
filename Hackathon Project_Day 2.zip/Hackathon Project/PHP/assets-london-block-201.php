<?php
include('utils.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blocks and Room Number</title>
    <link rel="login icon" href="../Image/ismt logo.jpg" type="logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN PAGE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>

<body>
    <div style="background: linear-gradient(to right,#3962AE, #413692 );">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="text-uppercase text-center p-4 text-white" style="letter-spacing: 5px;">London Block /<span>
                            201</span></h1>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row mt-5">
            <div class="col-lg-3">
                <a href="description.php?asset=Chair-assets" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Chair assets</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-chair fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Projector-assets" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Projector assets</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="bi bi-projector fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=White-board-assets" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>White-board assets</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="bi bi-fullscreen fs-1"></i></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Internet" class="text-decoration-none">
                    <div class="card text-bg-danger mb-3">
                        <div class="card-header">
                            <h5>Internet</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-wifi fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Projector-screen" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Projector screen</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="bi bi-border-all fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Lights" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Lights</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-regular fa-lightbulb fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Connection-points" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Connection points</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-plug fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Carpet" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Carpet</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-rug fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Air-conditioner" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Air-conditioner</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-temperature-low fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Fans" class="text-decoration-none">
                    <div class="card text-bg-danger mb-3">
                        <div class="card-header">
                            <h5>Fans</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-fan fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="description.php?asset=Miscellaneous" class="text-decoration-none">
                    <div class="card text-bg-success mb-3">
                        <div class="card-header">
                            <h5>Miscellaneous</h5>
                        </div>
                        <div class="card-body" style="height: 100px;">
                            <p class="card-text"><i class="fa-solid fa-circle-info fs-1"></i></p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</body>


</html>