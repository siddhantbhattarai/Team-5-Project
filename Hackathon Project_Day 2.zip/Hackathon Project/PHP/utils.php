<?php
function generateUrl($page, $params = []) {
    $url = $page;
    if (!empty($params)) {
        $query = http_build_query($params);
        $url .= '?' . $query;
    }
    return $url;
}
?>
