<?php
include('utils.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="login icon" href="../Image/ismt logo.jpg" type="logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Block</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        .bg-header {
            background: linear-gradient(#413692, #3962AE);
        }
        .bg-header img {
            width: 100px;
        }
        .block-wrapper {
            width: 300px;
            height: 250px;
            border-radius: 30px;
        }
        .color-changing-green-div {
            background-color: green !important;
            border-radius: 30px 30px 0 0 !important;
        }
        .color-changing-red-div {
            background-color: red !important;
            border-radius: 30px 30px 0 0 !important;
        }
        .white-div {
            border-radius: 0 0 30px 30px !important;
        }
        .bottom-end-20 {
            bottom: 20px;
            right: 20px;
        }
        .alignment-code {
            width: 130px;
            height: 130px;
        }
        .text-stamford {
            font-size: 1.35rem !important;
        }
        .text-london {
            font-size: 1.35rem !important;
        }
        @media only screen and (max-width: 600px) {
            .block-wrapper {
                width: 225px;
                height: 175px;
            }
            strong {
                font-size: 1.45rem !important;
            }
            .alignment-code {
                width: 90px;
                height: 90px;
            }
        }
        @media only screen and (max-width: 500px) {
            .block-wrapper {
                width: 200px;
                height: 175px;
            }
            strong {
                font-size: 1.45rem !important;
            }
            .alignment-code {
                width: 90px;
                height: 90px;
            }
        }
    </style>
</head>
<body>
    <div class="whole-bg-container">
        <section class="header">
            <div class="bg-header py-3 d-flex justify-content-center">
                <img src="../Image/ismt-sunderland-white.png" alt="">
            </div>
        </section>
        <section class="blocks-section my-4">
            <div class="container">
                <div class="row g-4 justify-content-center">
                    <?php
                    $blocks = [
                        'Block-A' => ['code' => 'a', 'class' => ''],
                        'Block-B' => ['code' => 'b', 'class' => ''],
                        'Block-C' => ['code' => 'c', 'class' => ''],
                        'London-Block' => ['code' => 'LONDON', 'class' => 'text-london'],
                        'Stamford-Block' => ['code' => 'STAMFORD', 'class' => 'text-stamford']
                    ];

                    foreach ($blocks as $block => $info) {
                        echo '<div class="col-lg-4 col-md-6 col-sm-6 col-6 d-flex justify-content-center">';
                        echo '<a href="' . generateUrl('table.php', ['block' => $block]) . '">';
                        echo '<div class="block-wrapper shadow position-relative">';
                        echo '<div class="position-absolute d-flex align-items-center justify-content-center w-100" style="height: 100%;">';
                        echo '<div class="alignment-code rounded-circle z-2 bg-white shadow d-flex align-items-center justify-content-center">';
                        echo '<div class="text-wrapper text-center">';
                        echo '<strong class="text-uppercase fs-2 text-black ' . $info['class'] . '">' . $info['code'] . '</strong>';
                        echo '<div class="text-uppercase text-black">block</div>';
                        echo '</div></div></div>';
                        echo '<div class="color-changing-green-div color-changing-red-div h-50"></div>';
                        echo '<div class="white-div h-50 position-relative">';
                        echo '<i class="bi bi-check-lg text-success position-absolute bottom-end-20 fs-3"></i>';
                        echo '<i class="bi bi-exclamation-circle text-danger position-absolute bottom-end-20 fs-3"></i>';
                        echo '</div></div></a></div>';
                    }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
